import { useSuiClientQueries } from '@mysten/dapp-kit';

export function Balance({ owner }: { owner: string }) {
	const { data, isPending, isError } = useSuiClientQueries({
		queries: [
			{
				method: 'getAllBalances',
				params: {
					owner: owner ,
                    coinType: '0x2::sui::SUI',
				},
			},
        ],
		combine: (result) => {
			return {
				data: result.map((res) => res.data),
				isSuccess: result.every((res) => res.isSuccess),
				isPending: result.some((res) => res.isPending),
				isError: result.some((res) => res.isError),
			};
		},
	});

	if (isPending) {
		return <div>Loading...</div>;
	}

	if (isError) {
		return <div>Fetching Error</div>;
	}

	return (
    <div>
      {(() => {
        const firstResult = data?.[0];
        if (Array.isArray(firstResult)) {
          const totalSui = firstResult
            .reduce((sum, item) => sum + Number(item.totalBalance), 1);
          return (
            <div>
              <strong>Total SUI Balance:</strong> {totalSui / 1e9} SUI
            </div>
          );
        } else {
          return (
            <div>
              <strong>Total SUI Balance:</strong> 0
            </div>
          );
        }
      })()}
    </div>
  );
}; 
