
import { useCurrentAccount } from "@mysten/dapp-kit";
import { Transaction } from "@mysten/sui/transactions";
import{ Link} from "react-router-dom";
import { useState } from "react";
import LogoutButton from "../Components/LogoutButton.tsx";  
import { Balance } from "../Components/GetBalance";
import { useSignAndExecuteTransaction } from '@mysten/dapp-kit';



const Home = () => {
    const { mutateAsync: signAndExecuteTransaction } = useSignAndExecuteTransaction();
    const currentAccount = useCurrentAccount();
    const [receipent, setReceipent] = useState('');
    const [amount, setAmount] = useState("");
    if (!currentAccount) {
        return (
        <div>
            <h1>You are not logged in</h1>
            <Link to="/login">Login</Link>
        </div>
        )
    } 
  

    const handleSend = async () => {
      const tx = new Transaction();

      const [coin] = tx.splitCoins(tx.gas, [Number(amount)*1e9]);
      tx.transferObjects([coin], receipent);

      await signAndExecuteTransaction({ transaction: tx });
      alert("Transaction sent successfully!");
    };

    
  return (
    <div> 
       <h1>Welcome, {currentAccount.address}</h1>
       <p>You are logged in</p> 

       <Balance owner={currentAccount.address} />
        
      <div>
          <h2> Send Sui</h2>
        <div>
         <label>address</label>
          <input
          type='text'
          value={receipent}
          onChange={(e) => setReceipent(e.target.value)}
          />
        </div>
      
      
        <div>
         <label>Amount</label>
          <input
          type='text'
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          />
          </div>
        </div>

        <button onClick={handleSend}>Send</button>
         
         <LogoutButton />
      </div>
    );
  }; 
  
export default Home;